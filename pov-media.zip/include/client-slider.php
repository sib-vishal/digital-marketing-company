<!-- <section class="overflow-hidden ">
    <div class="containerFull">

        <div class="">
            <div class=" clients">
                <div class="col-lg-2">
                    <div class="itemReview">
                        <img src="images/clients/client (1).png">
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="itemReview">
                        <img src="images/clients/client (2).png">
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="itemReview">
                        <img src="images/clients/client (3).png">
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="itemReview">
                        <img src="images/clients/client (4).png">
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="itemReview">
                        <img src="images/clients/client (5).png">
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="itemReview">
                        <img src="images/clients/client (6).png">
                    </div>
                </div>
            </div>
        </div>
    </div>

</section> -->
<section class="overflow-hidden py-5  ">
        <div class="containerFull">
            <h4 class="large_heading fontWeight800 text-center  font-Archivo">
                Our <span class="text-color1">Clients

                </span>
            </h4>

            <div class="mt-5">
                <div class=" clients">
                    <div class="col-lg-2">
                        <div class="itemReview">
                            <img src="images/clients/client (1).png">
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="itemReview">
                            <img src="images/clients/client (2).png">
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="itemReview">
                            <img src="images/clients/client (3).png">
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="itemReview">
                            <img src="images/clients/client (4).png">
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="itemReview">
                            <img src="images/clients/client (5).png">
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="itemReview">
                            <img src="images/clients/client (6).png">
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>